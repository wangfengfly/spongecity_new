<?php
// +----------------------------------------------------------------------
// | 英文检索数据表
// +----------------------------------------------------------------------
// | Copyright (c) 2016
// +----------------------------------------------------------------------
// | Author: dinglf
// +----------------------------------------------------------------------
// |2016-3-25 下午7:00:47
// +----------------------------------------------------------------------
defined('BASEPATH') OR exit('No direct script access allowed');
class Search_model extends MY_Model{
	
	public $_table = 'search_en';
	
	public function __construct(){
		parent::__construct();
	}
	
	public function addDataAll($data){
		$this->db->insert_batch($this->_table, $data);
	}

	/**
	 * 添加数据(跑数据使用)
	 */
	public function addData($data) {
		if ( empty($data) || !is_array( $data ) ){
			return false;
		}
		$query = $this->db->insert($this->_table, $data);
		return $this->db->insert_id();
	}

	/**
	 * 获取多条数据(搜索列表)
	 * @param array $where
	 * @param string $field
	 * @param string/int $limit
	 * @param int $offset
	 * @param string $order
	 */
	public function getDataObjLimit($where=array(), $field="*", $limit=15, $offset=0,  $order="id DESC",$search){
		if($where){
			$this->_where($where);
		}
    	$this->db->select($field);
    	if($search){
			$this->db->like('title', $search);
			//$this->db->like('brief', $search);
    	}
    	$this->db->order_by($order);
    	$this->db->limit($limit, $offset);
    	$res = $this->db->get($this->_table);
    	return $res->result();
    }

    /**
	 * 获取总数(搜索列表)
	 * @param unknown_type $where
	 * @param unknown_type $field
	 * @author Baip
	 */
	public function getTotal($where=array(), $field="*",$search){
		$this->_where($where);
		$this->db->select($field);
		if($search){
			$this->db->like('title', $search);
			//$this->db->like('brief', $search);
		}
		$count = $this->db->count_all_results($this->_table);
		return $count;
	}

	public function delData(array $where){
                if(!$where){
                        return false;
                }
                return $this->db->delete($this->_table, $where);
       }

}
