<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Admin Controller
 * Extends the Backend_Controller class and provides backend user management
 *
 * @package    新闻管理后台
 * @subpackage    Controllers
 * @category    Admin Management
 * @author    dinglf
 * Date 2016-3-23
 */
class News extends Backend_Controller {

    var $admin_url; //后台管理URL路径
    var $admin_folder; //后台管理文件路径

    function __construct()
    {
        parent::__construct();
        
        $this->load->model('News_model','news');

        $this->admin_url = $this->config->item('admin_url');
        $this->admin_folder = $this->config->item('admin_folder');
        $this->check_permission(array_key(config_item('admin_mask'), '土人新闻'));
    }
    
    /**
     * 新闻管理列表页
     */
    public function index(){

        $data['active_menu'] = 'news';
        $data['news_classify'] = $this->config->config['news_classify']; //新闻分类
        $data['news_status'] = $this->config->config['news_status']; //新闻状态
        
        $order = 'news.id desc';
        $page_size = $this->config->item('default_limit');

        $where = array();

        $total_count = $this->news->count_by($where);
        $pagination = ajax_page($total_count,$page_size,1);
        $data['pagination'] = $pagination;
        $data['news_list'] = $this->news->get_news_back_list($where,$order,$page_size,$page);
        $this->render($this->admin_folder.'/news_list',$data);
    }


    /*
     * 异步查询
     */
    public function search()
    {
        //判断请求类型
        if(!empty($_POST))
        {
            $keywords = $this->input->post('keywords');
            $page = $this->input->post('page');
            $status = $this->input->post('status');
            $classify = $this->input->post('classify');
            $news_classify = $this->config->config['news_classify']; //新闻分类
            $news_status = $this->config->config['news_status'];  //新闻状态

            $order = 'news.id desc';
            $where = array();

            if($status != -1){
                $where['news.status'] = $status;
                $order = 'news.top_time desc';
            }

            if($classify != -1){
                $where['news.classify'] = $classify;
            }
            
            $search = array('keywords'=>$keywords);

            $total_count = $this->news->getCountData($where, $search);
            $page_size = $this->config->item('default_limit');
            $pagination = ajax_page($total_count, $page_size, $page);
            $page = ($page-1)*$page_size;

            $topic_list = $this->news->get_news_back_list($where,$order,$page_size,$page,$search);
            //echo $this->db->last_query();
            $list = '';

            foreach($topic_list as $item)
            {
                $list .= '<tr>';
                $list .= '<td>';
                $list .= $item->id;
                $list .= '</td>';
                $list .= '<td>';
                $list .= '<a href="'.site_url("/news/detail/".$item->id).'" target="_blank" title="'.$item->title.'">'.msubstr($item->title,0,20).'</a>';
                $list .= '</td>';
                $list .= '<td>';
                $list .= $news_classify[$item->classify];
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->author;
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->comefrom;
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->hits;
                $list .= '</td>';
                $list .= '<td id="top_status_'.$item->id.'">';
                if($item->status == 0){
                $list .= '<span class="label label-important">待处理</span>';
                }else if($item->status == 1){
                $list .= '<span class="label label">已发布</span>';
                }else if($item->status == 2){
                $list .= '<span class="label label-warning">首页已置顶</span>';
                }
                $list .= '</td>';
                $list .= '<td>';
                $list .= time_format($item->postdate);
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->username;
                $list .= '</td>';
                $list .= '<td>';
                if($item->status == 2){
                    $list .= '<a href="/manage/news/edit/'.$item->id.'">编辑</a> | <a href="javascript:void(0)" onclick="untops('.$item->classify.','.$item->id.')">取消置顶</a> | <a href="javascript:void(0)" onclick="del('.$item->id.')">删除</a>';
                }else{
                    $list .= '<a href="/manage/news/edit/'.$item->id.'">编辑</a> | <a href="javascript:void(0)" onclick="tops('.$item->classify.','.$item->id.')">首页置顶</a> | <a href="javascript:void(0)" onclick="del('.$item->id.')">删除</a>';
                }
                $list .= '</td>';
                $list .= '</tr>';
            }
            echo json_encode(array('code' => 1, 'list' => $list, 'pagination' => $pagination));
            return;
        }
        echo json_encode(array('code' => 0));
    }
    
    /**
     * 发布新闻
     */
    public function add(){
    	$data = array();
    	$data['active_menu'] = 'news_add';
    	//引入表单验证类
    	$this->load->library('form_validation');
    	if ( IS_POST && $this->form_validation->run('news_create') ){
    		$post_data = $this->news->createData();
    		if ( $post_data ){
    			$insert_id = $this->news->addData($post_data);
    			if ( $insert_id ){
				if($post_data['status'] == 1){
					$this->load->model('Search_model','search');
					$searchData = array('type'=>2, 'linkid'=>$insert_id, 'title'=>$post_data['title'],
                        			'brief'=>$post_data['brief'],
                        			'label'=>$post_data['label'],
                        			'create_time'=>$post_data['postdate'],
                    			);
					$this->search->addData($searchData);
				}
    				$this->show_message('success', '发布成功', site_url($this->admin_url.'/news/index'));
                    //redirect(site_url($this->admin_url.'/news/index'));
    			}else{
    				$this->show_message('error', '发布失败', site_url($this->admin_url.'/news/index'));
    			}
    		}else{
    			$this->show_message('error', '参数错误');
    		}
    	}else{
            $data['_title'] = '发布中文新闻';
            $data['news_classify'] = $this->config->config['news_classify'];
            
            $this->render($this->admin_folder.'/news_create', $data);
        }
    }
    
    /**
     * 修改新闻
     */
    public function edit($id=0){
    	if ( empty( $id ) ){
    		$this->show_message('error', '参数错误', site_url($this->admin_url.'/news/index'));
    	}
    	$data = array();
    	$data['active_menu'] = 'news_edit';
        $data['info'] = $this->news->getFind(array('news.id'=>$id));

    	$this->load->library('form_validation');
    	if ( IS_POST && $this->form_validation->run('news_create') ){

    		$post_data = $this->news->createData();
            //如果项目置顶则不更新状态
            if($data['info']->status == 2){
                unset($post_data['status']);
            }
    		$res = $this->news->updateData( array('id'=>$id), $post_data);
    		if ( $res ){
			$this->load->model('Search_model','search');
       			if($post_data['status'] == 0){
            			$this->search->delData(array('type'=>2, 'linkid'=>$id));
       			}else{
           			if(!$this->search->getTotal(array('type'=>2, 'linkid'=>$id))){
                			$searchData = array('type'=>2, 'linkid'=>$id, 'title'=>$post_data['title'],
                                                'brief'=>$post_data['brief'],
                                                'label'=>$post_data['label'],
                                                'create_time'=>$post_data['postdate'],
                                        );
                			$this->search->addData($searchData);
           			}
       			}

    			$this->show_message('success','编辑成功', site_url($this->admin_url.'/news/index'));
    		}else{
    			$this->show_message('error','编辑失败', site_url($this->admin_url.'/news/index'));
    		}
    	}else{
    		
            $data['news_classify'] = $this->config->config['news_classify'];

            $this->load->vars('_title', '修改中文新闻');
    		$this->load->view($this->admin_folder.'/news_create', $data);
    	}
    }
    
    /**
     * 删除新闻数据
     */
    public function del(){
    	$id = intval( $this->input->post('id') );
    	$data['active_menu'] = 'news_del';
    	if ( empty( $id ) ){
    	    ajaxreturn(0,'参数错误');
            return;
        }
    	$info = $this->news->get_by('id',$id);
    	if(empty($info)){
    		ajaxreturn(2,'新闻不存在');
    		return;
    	}
    	$res = $this->news->deleteData(array('id'=>$id));
    	if(!$res){
    		ajaxreturn(3, '删除失败');
    	}else{
    		ajaxreturn(1, '删除成功');
    	}
    }

    /**
     * 添加置顶
     */
    public function tops(){
        $type = $this->input->post('type');
        $id = intval( $this->input->post('id') );
        $data['active_menu'] = 'news_tops';
        if ( empty( $id ) ){
            ajaxreturn(0,'参数错误');
            return;
        }
        $news_list = $this->news->getDataObj(array('classify'=>$type,'status'=>2),'id',10,0,'top_time desc');
        
        $info = $this->news->get_by('id',$id);
        if(empty($info)){
            ajaxreturn(2,'新闻不存在');
            return;
        }
        $post_data['top_time'] = time();
        $post_data['status'] = 2;
        $res = $this->news->updateData(array('id'=>$id),$post_data);
        
        if($res){
            if(count($news_list)>=9) {
                $end_res = end($news_list);
                $this->news->updateData(array('id'=>$end_res->id),array('status'=>1,'top_time'=>0));
            }
            ajaxreturn(1, '添加首页置顶成功');
        }else{
            ajaxreturn(3, '添加首页置顶失败');
        }
    }

    /**
     * 取消置顶
     */
    public function untops(){
        $type = $this->input->post('type');
        $id = intval( $this->input->post('id') );
        $data['active_menu'] = 'news_untops';
        if ( empty( $id ) ){
            ajaxreturn(0,'参数错误');
            return;
        }

        $info = $this->news->get_by('id',$id);
        if(empty($info)){
            ajaxreturn(2,'新闻不存在');
            return;
        }

        $res = $this->news->updateData(array('id'=>$id),array('status'=>1,'top_time'=>0));
        if($res){
            ajaxreturn(1, '取消置顶成功');
        }else{
            ajaxreturn(3, '取消置顶失败');
        }
    }
}
