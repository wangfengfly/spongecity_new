<?php
// +----------------------------------------------------------------------
// | 论文管理（添加、修改、删除等操作）
// +----------------------------------------------------------------------
// | Copyright (c) 2016
// +----------------------------------------------------------------------
// | Author: baiping 
// +----------------------------------------------------------------------
// |2016-3-28 下午3:35:56
// +----------------------------------------------------------------------
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Paper extends Backend_Controller{
	
	var $admin_folder; //后台管理文件路径
	
	function __construct()
	{
		parent::__construct();
		
		$this->load->model('Paper_model','paper');
		$this->admin_folder = $this->config->item('admin_folder');

		$this->check_permission(array_key(config_item('admin_mask'), '土人理念'));
	}
	
	/**
	 * 论文首页
	 */
	public function index(){
		$data = array();
		$data['active_menu'] = 'paper';
		
        $data['paper_status'] = $this->config->config['paper_status'];

        $order = 'paper.id desc';
        $page_size = $this->config->item('default_limit');

        $where = array();

        $total_count = $this->paper->count_by($where);
        $pagination = ajax_page($total_count,$page_size,1);
        $data['pagination'] = $pagination;
        $data['paper_list'] = $this->paper->get_paper_list($where,$order,$page_size,$page);
        $data['_title'] = '论文列表';
		$this->render($this->admin_folder.'/paper_index', $data);
	}
	
    /*
     * 异步查询
     */
    public function search()
    {
        //判断请求类型
        if(!empty($_POST))
        {
            $keywords = $this->input->post('keywords');
            $page = $this->input->post('page');
            $status = $this->input->post('status');

            $order = 'paper.id desc';
            if($status == -1){
                $where = array();
            }else{
                $where = array('paper.status'=>$status);
            }
            
            $search = array('keywords'=>$keywords);

            $total_count = $this->paper->getCountData($where, $search);
            $page_size = $this->config->item('default_limit');
            $pagination = ajax_page($total_count, $page_size, $page);
            $page = ($page-1)*$page_size;

            $paper_list = $this->paper->get_paper_list($where,$order,$page_size,$page,$search);
            $list = '';

            foreach($paper_list as $item)
            {
                $list .= '<tr>';
                $list .= '<td>';
                $list .= $item->id;
                $list .= '</td>';
                $list .= '<td>';
                $list .= '<a href="'.site_url('paper/detail/'.$item->id).'" target="_blank">'.$item->subject.'</a>';
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->publish;
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->author;
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->comefrom;
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->hits;
                $list .= '</td>';
                $list .= '<td>';
                if($item->status == 0){
                $list .= '<span class="label label-important">待处理</span>';
                }else{
                $list .= '<span class="label label">已发布</span>';
                }
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->username;
                $list .= '</td>';
                $list .= '<td>';
                $list .= time_format($item->postdate);
                $list .= '</td>';
                $list .= '<td>';
                $list .= '<a href="/manage/paper/modfiy/'.$item->id.'">编辑</a> | <a href="javascript:void(0)" class="del" onclick="del('.$item->id.')" >删除</a>';
                $list .= '</td>';
                $list .= '</tr>';
            }
            echo json_encode(array('code' => 1, 'list' => $list, 'pagination' => $pagination));
            return;
        }
        echo json_encode(array('code' => 0));
    }

	/**
	 * 添加论文
	 */
	public function create(){
		$data = array();
		$data['active_menu'] = 'paper_create';
		//引入表单验证类
		$this->load->library('form_validation');
		if ( IS_POST && $this->form_validation->run('paper_create') ){
			$insert_id = $this->paper->addData();
			if ( $insert_id ){
				$insert_data = $this->paper->postData();
				if($insert_data['status'] == 1){
					$this->load->model('Search_model','search');
					$searchData = array('type'=>5, 'linkid'=>$insert_id, 'title'=>$insert_data['subject'],
        					'brief'=>$insert_data['abstract'],
       						 'label'=>$insert_data['label'],
        					'create_time'=>$insert_data['postdate'],
					);
					$this->search->addData($searchData);
				}
				$this->show_message('success', '发布成功',site_url($this->admin_url.'/paper/index'));
			}else{
				$this->show_message('error', '发布失败');
			}
		}else{
			$this->load->vars('_title', '添加论文');
			$this->render($this->admin_folder.'/paper_create', $data);
		}	
	}

	/**
	 * 修改论文
	 */
	public function modfiy($id=0){
		if ( empty( $id ) ){
			$this->show_message('error', '参数错误', site_url($this->admin_url.'/paper/index'));
		}
		$data['active_menu'] = 'paper_modfiy';
		
		$this->load->library('form_validation');
		if ( IS_POST && $this->form_validation->run('paper_create') ){
			$res = $this->paper->updateData( array("id"=>$id));
			if ( $res ){
				$this->load->model('Search_model','search');
       				$post_data = $this->paper->postData();
       				if($post_data['status'] == 0){
            				$this->search->delData(array('type'=>5, 'linkid'=>$id));
       				}else{
           				if(!$this->search->getTotal(array('type'=>5, 'linkid'=>$id))){
                
                				$searchData = array('type'=>5, 'linkid'=>$id, 'title'=>$post_data['subject'],
        						'brief'=>$post_data['abstract'],
        						'label'=>$post_data['label'],
        						'create_time'=>$post_data['postdate'],
						);
                				$this->search->addData($searchData);
           				}
       				}
				$this->show_message('success','修改成功', site_url($this->admin_url.'/paper/index'));
			}else{
				$this->show_message('error','修改失败', site_url($this->admin_url.'/paper/index'));
			}
		}else{
			$data['info'] = $this->paper->getFind(array('paper.id'=>$id));
			
			$this->load->vars('_title', '修改论文');
			$this->load->view($this->admin_folder.'/paper_create', $data);
		}	
	}
	
	/**
	 * 删除论文 
	 * @author
	 */
	public function del(){
		$id = $this->input->post('id');
		if ( empty( $id ) ){
			ajaxreturn('0', '参数错误');
		}
		//判断传入的id是否在当前的表中
		$data = $this->paper->getFind(array('paper.id'=>$id));
		if ( count($data) > 0 ){
			$state = $this->paper->deleteData(array('id'=>$id));
			if ( $state ){
				ajaxreturn('1', '删除成功');
			}else{
				ajaxreturn('2', '操作失败');
			}
		}else{
			ajaxreturn('3', '该条信息不存在');
		}
	}
	
}
