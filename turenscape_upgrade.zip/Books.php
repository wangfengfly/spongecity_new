<?php
// +----------------------------------------------------------------------
// | 出版管理（添加、修改、删除等操作）
// +----------------------------------------------------------------------
// | Copyright (c) 2015
// +----------------------------------------------------------------------
// | Author: baiping 125618036@qq.com http://www.webipcode.com
// +----------------------------------------------------------------------
// |2016-3-28 下午3:35:56
// +----------------------------------------------------------------------
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Books extends Backend_Controller{
	
	var $admin_folder; //后台管理文件路径
	
	function __construct()
	{
		parent::__construct();
	
		$this->load->model('Books_model','books');
		$this->admin_folder = $this->config->item('admin_folder');

		$this->check_permission(array_key(config_item('admin_mask'), '土人理念'));
	}
	
	/**
	 * 出版首页
	 */
	public function index(){
        $data['active_menu'] = 'books';
        $data['books_status'] = $this->config->config['books_status'];

        $order = 'books.id desc';
        $page_size = $this->config->item('default_limit');

        $where = array();

        $total_count = $this->books->count_by($where);
        $pagination = ajax_page($total_count,$page_size,1);
        $data['pagination'] = $pagination;
        $data['books_list'] = $this->books->get_books_list($where,$order,$page_size,$page);

        $data['_title'] = '出版列表';
		$this->render($this->admin_folder.'/books_index', $data);
	}
	
	/**
	 * 添加中文出版物 
	 */
	public function create(){
		$data = array();
		$data['active_menu'] = 'books_create';
		//引入表单验证类
		$this->load->library('form_validation');
		if ( IS_POST && $this->form_validation->run('books_create') ){
			//加载论文模型
			$insert_id = $this->books->addData();
			if ( $insert_id ){
				$insert_data = $this->books->postData();
				if($insert_data['status'] == 1){
    					$this->load->model('Search_model','search');
    					$searchData = array('type'=>6, 'linkid'=>$insert_id, 'title'=>$insert_data['subject'],
            					'brief'=>$insert_data['abstract'],
            					'label'=>$insert_data['label'],
            					'create_time'=>$insert_data['postdate'],
    					);
    					$this->search->addData($searchData);
				}

				$this->show_message('success', '操作成功',site_url($this->admin_url.'/books/index'));
			}else{
				$this->show_message('error', '操作失败');
			}
		}else{
			$this->load->vars('_title', '添加出版物');
			$this->render($this->admin_folder.'/books_create', $data);
		}	
	}

	/**
	 * 修改出版
	 */
	public function modfiy($id=0){

		if ( empty( $id ) ){
			$this->show_message('error', '参数错误', site_url($this->admin_url.'/books/index'));
		}

		$data = array();
		$data['active_menu'] = 'books_modfiy';

		$this->load->library('form_validation');
		if ( IS_POST && $this->form_validation->run('books_create') ){

			$status = $this->books->updateData( array("id"=>$id));
			if ( $status ){
				$this->load->model('Search_model','search');
       				$post_data = $this->books->postData();
       				if($post_data['status'] == 0){
            				$this->search->delData(array('type'=>6, 'linkid'=>$id));
       				}else{
           				if(!$this->search->getTotal(array('type'=>6, 'linkid'=>$id))){
                
                				$searchData = array('type'=>6, 'linkid'=>$id, 'title'=>$post_data['subject'],
            						'brief'=>$post_data['abstract'],
           						 'label'=>$post_data['label'],
            						'create_time'=>$post_data['postdate'],
    						);
                				$this->search->addData($searchData);
           				}
       				}

				$this->show_message('success','编辑成功', site_url($this->admin_url.'/books/index'));
			}else{
				$this->show_message('error','编辑失败', site_url($this->admin_url.'/books/index'));
			}
		}else{
			$data['info'] = $this->books->getFind(array('books.id'=>$id));

			$this->load->vars('_title', '修改出版物');
			$this->load->view($this->admin_folder.'/books_create', $data);
		}	
	}
	
	/**
	 * 删除出版物 
	 * @author
	 */
	public function del(){
		$id = $this->input->post('id');
		if ( empty( $id ) ){
			ajaxreturn('0', '参数错误');
		}
		//判断传入的id是否在当前的表中
		$data = $this->books->getFind(array('books.id'=>$id));
		if ( count($data) > 0 ){
			$state = $this->books->deleteData(array('id'=>$id));
			if ( $state ){
				ajaxreturn('1', '删除成功');
			}else{
				ajaxreturn('2', '操作失败');
			}
		}else{
			ajaxreturn('3', '该条信息不存在');
		}
	}

	/*
     * 异步查询
     */
    public function search()
    {
        //判断请求类型
        if(!empty($_POST))
        {
            $keywords = $this->input->post('keywords');
            $page = $this->input->post('page');
            $status = $this->input->post('status');

            $order = 'books.id desc';
            if($status == -1){
                $where = array();
            }else{
                $where = array('books.status'=>$status);
            }
            
            $search = array('keywords'=>$keywords);

            $total_count = $this->books->getCountData($where, $search);
            $page_size = $this->config->item('default_limit');
            $pagination = ajax_page($total_count, $page_size, $page);
            $page = ($page-1)*$page_size;

            $books_list = $this->books->get_books_list($where,$order,$page_size,$page,$search);
            $list = '';

            foreach($books_list as $item)
            {
                $list .= '<tr>';
                $list .= '<td>';
                $list .= $item->id;
                $list .= '</td>';
                $list .= '<td>';
                $list .= '<a href="'.site_url('books/detail/'.$item->id).'" target="_blank" title="'.$item->subject.'">'.$item->subject.'</a>';
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->publisher;
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->author;
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->price;
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->hits;
                $list .= '</td>';
                $list .= '<td>';
                if($item->status == 0){
                $list .= '<span class="label label-important">待处理</span>';
                }else{
                $list .= '<span class="label label">已发布</span>';
                }
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->username;
                $list .= '</td>'; 
                $list .= '<td>';
                $list .= time_format($item->postdate);
                $list .= '</td>';
                $list .= '<td>';
                $list .= '<a href="/manage/books/modfiy/'.$item->id.'">编辑</a> | <a href="javascript:void(0)" class="del" onclick="del('.$item->id.')">删除</a>';
                $list .= '</td>';
                $list .= '</tr>';
            }
            echo json_encode(array('code' => 1, 'list' => $list, 'pagination' => $pagination));
            return;
        }
        echo json_encode(array('code' => 0));
    }
}
