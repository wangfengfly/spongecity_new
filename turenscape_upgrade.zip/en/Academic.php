<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// +----------------------------------------------------------------------
// | 后台 英文学术交流 Controller层
// +----------------------------------------------------------------------
// | @Author: dinglf
// +----------------------------------------------------------------------
// | @Date: 2016年8月4日 下午4:28:32
// +----------------------------------------------------------------------
class Academic extends Backend_Controller {

    var $admin_url; //后台管理URL路径
    var $admin_folder; //后台管理文件路径

    function __construct()
    {
        parent::__construct();
        
        $this->load->model('en/Academic_model','academic_en');

        $this->admin_url = $this->config->item('admin_url');
        $this->admin_folder = $this->config->item('admin_folder');
        $this->check_permission(array_key(config_item('admin_mask'), '土人新闻'));
    }
    
    /**
     * 新闻管理列表页
     */
    public function index(){

        $data['active_menu'] = 'academic_en';
        $data['academic_status'] = $this->config->config['academic_status']; //学术交流状态
        
        $order = 'academic_en.id desc';
        $page_size = $this->config->item('default_limit');

        $where = array();

        $total_count = $this->academic_en->count_by($where);
        $pagination = ajax_page($total_count,$page_size,1);
        $data['pagination'] = $pagination;
        $data['academic_list'] = $this->academic_en->get_academic_back_list($where,$order,$page_size,$page);
        $this->render($this->admin_folder.'/academic_en_list',$data);
    }


    /*
     * 异步查询
     */
    public function search()
    {
        //判断请求类型
        if(!empty($_POST))
        {
            $keywords = $this->input->post('keywords');
            $page = $this->input->post('page');
            $status = $this->input->post('status');
            $academic_status = $this->config->config['academic_status'];  //项目状态

            $order = 'academic_en.id desc';
            $where = array();

            if($status != -1){
                $where['academic_en.status'] = $status;
                $order = 'academic_en.top_time desc';
            }
            
            $search = array('keywords'=>$keywords);

            $total_count = $this->academic_en->getCountData($where, $search);
            $page_size = $this->config->item('default_limit');
            $pagination = ajax_page($total_count, $page_size, $page);
            $page = ($page-1)*$page_size;

            $topic_list = $this->academic_en->get_academic_back_list($where,$order,$page_size,$page,$search);
            //echo $this->db->last_query();
            $list = '';

            foreach($topic_list as $item)
            {
                $list .= '<tr>';
                $list .= '<td>';
                $list .= $item->id;
                $list .= '</td>';
                $list .= '<td>';
                $list .= '<a href="'.site_url("/en/academic/detail/".$item->id).'" target="_blank" title="'.$item->title.'">'.$item->title.'</a>';
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->speech_subject;
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->sponsors;
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->speech_place;
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->speech_time;
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->hits;
                $list .= '</td>';
                $list .= '<td id="top_status_'.$item->id.'">';
                if($item->status == 0){
                $list .= '<span class="label label-important">待处理</span>';
                }else if($item->status == 1){
                $list .= '<span class="label label">已发布</span>';
                }else if($item->status == 2){
                $list .= '<span class="label label-warning">首页已置顶</span>';
                }
                $list .= '</td>';
                $list .= '<td>';
                $list .= time_format($item->create_time);
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->username;
                $list .= '</td>';
                $list .= '<td>';
                if($item->status == 2){
                    $list .= '<a href="/manage/en/academic/edit/'.$item->id.'">编辑</a> | <a href="javascript:void(0)" onclick="untops('.$item->id.')">取消置顶</a> | <a href="javascript:void(0)" onclick="del('.$item->id.')">删除</a>';
                }else{
                    $list .= '<a href="/manage/en/academic/edit/'.$item->id.'">编辑</a> | <a href="javascript:void(0)" onclick="tops('.$item->id.')">首页置顶</a> | <a href="javascript:void(0)" onclick="del('.$item->id.')">删除</a>';
                }
                $list .= '</td>';
                $list .= '</tr>';
            }
            echo json_encode(array('code' => 1, 'list' => $list, 'pagination' => $pagination));
            return;
        }

        echo json_encode(array('code' => 0));
    }
    
    /**
     * 发布学术交流
     */
    public function add(){
    	$data = array();
    	$data['active_menu'] = 'academic_en_add';
    	//引入表单验证类
    	$this->load->library('form_validation');
    	if ( IS_POST && $this->form_validation->run('academic_en_create') ){
    		$post_data = $this->academic_en->createData();
    		if ( $post_data ){
    			$insert_id = $this->academic_en->addData($post_data);
    			if ( $insert_id ){
				if($post_data['status'] == 1){
 				   	$this->load->model('en/Search_model','search');
    					$searchData = array('type'=>3, 'linkid'=>$insert_id, 'title'=>$post_data['title'],
            					'brief'=>$post_data['speech_subject'],
            					'label'=>$post_data['label'],
            					'create_time'=>$post_data['create_time'],
    					);
    					$this->search->addData($searchData);
				}
    				$this->show_message('success', '发布成功', site_url($this->admin_url.'/en/academic/index'));
    			}else{
    				$this->show_message('error', '发布失败', site_url($this->admin_url.'/en/academic/index'));
    			}
    		}else{
    			$this->show_message('error', '参数错误');
    		}
    	}else{
            $data['_title'] = '发布英文学术交流';
            $this->render($this->admin_folder.'/academic_en_create', $data);
        }
    }
    
    /**
     * 修改学术交流
     */
    public function edit($id){
    	if ( empty( $id ) ){
    		$this->show_message('error', '参数错误', site_url($this->admin_url.'/en/academic/index'));
    	}
    	$data = array();
    	$data['active_menu'] = 'academic_en_edit';
    	$data['info'] = $this->academic_en->getFind(array('academic_en.id'=>$id));

    	if ( IS_POST || $this->form_validation->run('academic_en_create') ){
    		$post_data = $this->academic_en->createData();

            if($data['info']->status == 2){
                unset($post_data['status']);
            }
    		$res = $this->academic_en->updateData(array("id"=>$id), $post_data);
    		if ( $res ){
			$this->load->model('en/Search_model','search');
                if($post_data['status'] == 0){
                        $this->search->delData(array('type'=>3, 'linkid'=>$id));
                }else{
                        if(!$this->search->getTotal(array('type'=>3, 'linkid'=>$id))){
                                $searchData = array('type'=>3, 'linkid'=>$id, 'title'=>$post_data['title'],
                                    'brief'=>$post_data['speech_subject'],
                                    'label'=>$post_data['label'],
                                    'create_time'=>$post_data['create_time'],
                                );
                                $this->search->addData($searchData);
                        }
                }
    			$this->show_message('success','修改成功', site_url($this->admin_url.'/en/academic/index'));
                //redirect(site_url($this->admin_url.'/academic/index'));
    		}else{
    			$this->show_message('error','修改失败', site_url($this->admin_url.'/en/academic/index'));
    		}
    	}else{
    		
    		$this->load->vars('_title', '编辑学术交流');
    		$this->load->view($this->admin_folder.'/academic_en_create', $data);
    	}
    }
    
    /**
     * 删除学术交流
     */
    public function del(){
    	$id = intval( $this->input->post('id') );
    	$data['active_menu'] = 'delete_en_del';
    	if ( empty( $id ) ){
    		$this->show_message('error', '参数错误', site_url($this->admin_url.'/en/academic/index'));
    	}
    	$info = $this->academic_en->get_by('id',$id);
    	if(empty($info)){
    		ajaxreturn(0,'学术交流不存在');
    		return;
    	}
    	$res = $this->academic_en->deleteData(array('id'=>$id));
    	if(!$res){
    		ajaxreturn(0, '删除失败');
    	}else{
    		ajaxreturn(1, '删除成功');
    	}
    }

    /**
     * 添加置顶
     */
    public function tops(){
        $id = intval( $this->input->post('id') );
        $data['active_menu'] = 'academic_en_tops';
        if ( empty( $id ) ){
            ajaxreturn(0,'参数错误');
            return;
        }
        $academic_list = $this->academic_en->getDataObj(array('status'=>2),'id',10,0,'top_time desc');
        
        $info = $this->academic_en->get_by('id',$id);
        if(empty($info)){
            ajaxreturn(2,'学术不存在');
            return;
        }
        $post_data['top_time'] = time();
        $post_data['status'] = 2;
        $res = $this->academic_en->updateData(array('id'=>$id),$post_data);
        
        if($res){
            if(count($academic_list)>=9) {
                $end_res = end($academic_list);
                $this->academic_en->updateData(array('id'=>$end_res->id),array('status'=>1,'top_time'=>0));
            }
            ajaxreturn(1, '添加列表置顶成功');
        }else{
            ajaxreturn(3, '添加列表置顶失败');
        }
    }

    /**
     * 取消置顶
     */
    public function untops(){
        $id = intval( $this->input->post('id') );
        $data['active_menu'] = 'academic_en_untops';
        if ( empty( $id ) ){
            ajaxreturn(0,'参数错误');
            return;
        }
        
        $info = $this->academic_en->get_by('id',$id);
        if(empty($info)){
            ajaxreturn(2,'学术不存在');
            return;
        }
        $res = $this->academic_en->updateData(array('id'=>$id),array('status'=>1,'top_time'=>0));
        if($res){
            ajaxreturn(1, '取消列表置顶成功');
        }else{
            ajaxreturn(3, '取消列表置顶失败');
        }
    }

    /**
     * 删除封面图
     */
    public function cancel(){
        $path = $this->input->post('path');
        $data['active_menu'] = 'academic_en_cancel';
        if ( empty( $path ) ){
            ajaxreturn(0,'参数错误');
            return;
        }
        $this->load->model('Image_model','image');
        $info = $this->image->getFind(array('path'=>$path));
        if(!$info){
            ajaxreturn(2,'该图片不存在');
            return;
        }
        $res = $this->image->deleteData(array('id'=>$info['id']));
        if($res){
            $acinfo = $this->academic_en->updateData(array('coverpic'=>$path),array('coverpic'=>''));
            if($acinfo){
                ajaxreturn(1, '删除图片成功');
                return;
            }else{
                ajaxreturn(4, '删除图片失败');
            }
        }else{
            ajaxreturn(3, '删除图片失败');
        }
    }
}
