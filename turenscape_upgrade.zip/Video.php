<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// +----------------------------------------------------------------------
// | 视频动态 Controller层
// +----------------------------------------------------------------------
// | @Author: dinglf
// +----------------------------------------------------------------------
// | @Date: 2016年3月29日 下午4:28:32
// +----------------------------------------------------------------------
class Video extends Backend_Controller {

    var $admin_url; //后台管理URL路径
    var $admin_folder; //后台管理文件路径

    function __construct()
    {
        parent::__construct();
        
        $this->load->model('Video_model','video');

        $this->admin_url = $this->config->item('admin_url');
        $this->admin_folder = $this->config->item('admin_folder');
        $this->check_permission(array_key(config_item('admin_mask'), '土人新闻'));
    }
    
    /**
     * 视频动态管理列表页
     */
    public function index(){

        $data['active_menu'] = 'video';
        $data['video_status'] = $this->config->config['video_status']; //视频动态状态
        
        $order = 'video.create_time desc';
        $page_size = $this->config->item('default_limit');

        $where = array();

        $total_count = $this->video->count_by($where);
        $pagination = ajax_page($total_count,$page_size,1);
        $data['pagination'] = $pagination;
        $data['video_list'] = $this->video->get_video_back_list($where,$order,$page_size,$page);
        $this->render($this->admin_folder.'/video_list',$data);
    }

    /**
     * 添加视频动态
     */
    public function add(){
        $data['active_menu'] = 'video_add';
        
        $this->load->library('form_validation');
        if(IS_POST && $this->form_validation->run('video_add')){
            $insert_data['title'] = $this->input->post('title');
            $insert_data['coverpic'] = $this->input->post('coverpic');
            $insert_data['video_url'] = $this->input->post('video_url');
            $insert_data['brief'] = $this->input->post('brief');
            $insert_data['guests'] = $this->input->post('guests');
            $insert_data['column'] = $this->input->post('column');
            $insert_data['show_time'] = $this->input->post('show_time');
            $insert_data['content'] = $this->input->post('content',false);
            $insert_data['label'] = $this->input->post('label');
            $insert_data['status'] = $this->input->post('status');
            $insert_data['create_time'] = $this->input->post('create_time');
            $insert_data['create_time'] = !empty($insert_data['create_time']) ? strtotime($insert_data['create_time']) : time();
            $insert_data['admin_id'] = $this->session->userdata('admin_id');

            $res = $this->video->insert($insert_data);
            if($res){
		if($insert_data['status'] == 1){
			$this->load->model('Search_model','search');
			$searchData = array('type'=>4, 'linkid'=>$res, 'title'=>$insert_data['title'],
        			'brief'=>$insert_data['brief'],
        			'label'=>$insert_data['label'],
       				 'create_time'=>$insert_data['create_time'],
			);
			$this->search->addData($searchData);
		}
                $this->show_message('success', '发布成功', site_url($this->admin_url.'/video/index'));
            }else{
                $this->show_message('error', '发布失败', site_url($this->admin_url.'/video/index'));
            }
        }else{
            $data['_title'] = '添加视频动态';
            
            $data['video_status'] = $this->config->config['video_status'];
            $this->render($this->admin_folder.'/video_add',$data);;
        }
    }

    /*编辑视频动态*/
    public function edit($id = 0){
        $data['active_menu'] = 'video_edit';
        $info = $this->video->get_by('id',$id);
        $data['video'] = $info;

        $this->load->library('form_validation');
        if(IS_POST && $this->form_validation->run('video_add')){
            $update_data['title'] = $this->input->post('title');
            $update_data['coverpic'] = $this->input->post('coverpic');
            $update_data['video_url'] = $this->input->post('video_url');
            $update_data['brief'] = $this->input->post('brief');
            $update_data['guests'] = $this->input->post('guests');
            $update_data['column'] = $this->input->post('column');
            $update_data['show_time'] = $this->input->post('show_time');
            $update_data['content'] = $this->input->post('content',false);
            $update_data['label'] = $this->input->post('label');
            if($info->status != 2){
                $update_data['status'] = $this->input->post('status');
            }
            $update_data['create_time'] = $this->input->post('create_time');
            $update_data['create_time'] = !empty($update_data['create_time']) ? strtotime($update_data['create_time']) : time();
            $update_data['admin_id'] = $this->session->userdata('admin_id');
            $update_data['update_time'] = time();
            
            $res = $this->video->update($id,$update_data);
            if($res){
		$this->load->model('Search_model','search');
       		if($post_data['status'] == 0){
            		$this->search->delData(array('type'=>4, 'linkid'=>$id));
       		}else{
           		if(!$this->search->getTotal(array('type'=>4, 'linkid'=>$id))){
                		$searchData = array('type'=>4, 'linkid'=>$id, 'title'=>$update_data['title'],
        				'brief'=>$update_data['brief'],
        				'label'=>$update_data['label'],
        				'create_time'=>$update_data['create_time'],
				);
                		$this->search->addData($searchData);
           		}
       		}
                $this->show_message('success', '编辑成功', site_url($this->admin_url.'/video/index'));
            }else{
                $this->show_message('error', '编辑失败', site_url($this->admin_url.'/video/index'));
            }
        }else{
            $data['_title'] = '编辑视频动态';
            $data['video_status'] = config_item('video_status');
            $this->render($this->admin_folder.'/video_add',$data);
        }
    }

    /*删除视频动态*/
    public function del($id = 0)
    {
        $id = $this->input->post('id');
        $data['active_menu'] = 'video_del';
        $info = $this->video->get_by('id',$id);
        if(empty($info)){
            echo json_encode(array('code' => 1,'msg'=>'视频不存在'));
            return;
        }

        $res = $this->video->delete($id);
        if(!$res){
            echo json_encode(array('code' => 2,'msg'=>'删除失败'));
            return;
        }
        echo json_encode(array('code' => 0,'msg'=>'删除成功'));
    }
    /*
     * 异步查询
     */
    public function search()
    {
        //判断请求类型
        if(!empty($_POST))
        {
            $keywords = $this->input->post('keywords');
            $page = $this->input->post('page');
            $status = $this->input->post('status');
            $video_status = $this->config->config['video_status'];  //项目状态

            $order = 'video.create_time desc';
            $where = array();

            if($status != -1){
                $where['video.status'] = $status;
                $order = 'video.top_time desc';
            }
            
            $search = array('keywords'=>$keywords);

            $total_count = $this->video->getCountData($where, $search);
            $page_size = $this->config->item('default_limit');
            $pagination = ajax_page($total_count, $page_size, $page);
            $page = ($page-1)*$page_size;

            $topic_list = $this->video->get_video_back_list($where,$order,$page_size,$page,$search);
            //echo $this->db->last_query();
            $list = '';

            foreach($topic_list as $item)
            {
                $list .= '<tr>';
                $list .= '<td>';
                $list .= $item->id;
                $list .= '</td>';
                $list .= '<td>';
                $list .= '<a href="'.site_url('video/detail/'.$item->id).'" target="_blank" title="'.$item->title.'">'.$item->title.'</a>';
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->guests;
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->column;
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->show_time;
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->video_url;
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->hits;
                $list .= '</td>';
                $list .= '<td id="top_status_'.$item->id.'">';
                if($item->status == 0){
                $list .= '<span class="label label-important">待处理</span>';
                }else if($item->status == 1){
                $list .= '<span class="label label">已发布</span>';
                }else if($item->status == 2){
                $list .= '<span class="label label-warning">首页已置顶</span>';
                }
                $list .= '</td>';
                $list .= '<td>';
                $list .= time_format($item->create_time);
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->username;
                $list .= '</td>';
                $list .= '<td>';
                if($item->status == 2){
                    $list .= '<a href="/manage/video/edit/'.$item->id.'">编辑</a> | <a href="javascript:void(0)" onclick="untops('.$item->id.')">取消置顶</a> | <a href="javascript:void(0)" onclick="del('.$item->id.')">删除</a>';
                }else{
                    $list .= '<a href="/manage/video/edit/'.$item->id.'">编辑</a> | <a href="javascript:void(0)" onclick="tops('.$item->id.')">首页置顶</a> | <a href="javascript:void(0)" onclick="del('.$item->id.')">删除</a>';
                }
                $list .= '</td>';
                $list .= '</tr>';
            }
            echo json_encode(array('code' => 1, 'list' => $list, 'pagination' => $pagination));
            return;
        }

        echo json_encode(array('code' => 0));
    }

    /**
     * 添加置顶
     */
    public function tops(){
        $id = intval( $this->input->post('id') );
        $data['active_menu'] = 'video_tops';
        if ( empty( $id ) ){
            ajaxreturn(0,'参数错误');
            return;
        }
        $video_list = $this->video->getDataObj(array('status'=>2),'id',10,0,'top_time desc');
        
        $info = $this->video->get_by('id',$id);
        if(empty($info)){
            ajaxreturn(2,'视频不存在');
            return;
        }
        $post_data['top_time'] = time();
        $post_data['status'] = 2;
        $res = $this->video->updateData(array('id'=>$id),$post_data);
        
        if($res){
            if(count($video_list)>=9) {
                $end_res = end($video_list);
                $this->video->updateData(array('id'=>$end_res->id),array('status'=>1,'top_time'=>0));
            }
            ajaxreturn(1, '添加首页置顶成功');
        }else{
            ajaxreturn(3, '添加首页置顶失败');
        }
    }

    /**
     * 取消置顶
     */
    public function untops(){
        $id = intval( $this->input->post('id') );
        $data['active_menu'] = 'video_untops';
        if ( empty( $id ) ){
            ajaxreturn(0,'参数错误');
            return;
        }
        
        $info = $this->video->get_by('id',$id);
        if(empty($info)){
            ajaxreturn(2,'视频不存在');
            return;
        }
        $res = $this->video->updateData(array('id'=>$id),array('status'=>1,'top_time'=>0));
        
        if($res){
            ajaxreturn(1, '取消首页置顶成功');
        }else{
            ajaxreturn(3, '取消首页置顶失败');
        }
    }
}
