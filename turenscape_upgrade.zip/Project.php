<?php
// +----------------------------------------------------------------------
// | 中文项目管理  Controller
// +----------------------------------------------------------------------
// | @Author: dinglf
// +----------------------------------------------------------------------
// | @Date: 2016年3月29日 上午10:42:30
// +----------------------------------------------------------------------
defined('BASEPATH') OR exit('No direct script access allowed');

class Project extends Backend_Controller {
	
	protected $admin_url; //后台管理URL路径
	protected $admin_folder; //后台管理文件路径
	
	function __construct() {
		parent:: __construct();
		
		$this->load->model('Project_model','project');

		$this->admin_url = $this->config->item('admin_url');
		$this->admin_folder = $this->config->item('admin_folder');
		$this->check_permission(array_key(config_item('admin_mask'), '土人项目'));
	}
	
	/**
	 * 项目管理列表页
	 * 
	 */
	public function index() {

		$data['active_menu'] = 'project';
		$data['project_classify'] = $this->config->config['project_classify']; //项目分类
		$data['project_status'] = $this->config->config['project_status']; //项目状态
        
        $order = 'project.id desc';
        $page_size = $this->config->item('default_limit');

        $where = array();

        $total_count = $this->project->count_by($where);
        $pagination = ajax_page($total_count,$page_size,1);
        $data['pagination'] = $pagination;
        $data['project_list'] = $this->project->get_project_back_list($where,$order,$page_size,$page);
        $this->render($this->admin_folder.'/project_list',$data);
	}
	
    /**
     * 添加项目
     */
    public function add(){
        $data['active_menu'] = 'project_add';
    
        $this->load->library('form_validation');
        if(IS_POST && $this->form_validation->run('project_add') != false){
                $post_data = $this->project->createData();
                $imgs_data = $this->input->post('imgs'); //图片单独处理

                $res = $this->project->addData($post_data);
			
                if($res){
			if($post_data['status'] == 1){
		    		$this->load->model('Search_model','search');
		    		$searchData = array('type'=>1, 'linkid'=>$res, 'title'=>$post_data['title'],
					'brief'=>mb_substr(strip_tags($post_data['content']), 0, 300),
					'label'=>$post_data['label'],'create_time'=>$post_data['postdate'],
		    		);
			
		    		$this->search->addData($searchData);
			}

                    //插入图片
                    if($imgs_data){
                        $this->load->model('Project_image_model','project_image');
                        foreach ($imgs_data as $key => $value) {
                            $img_insert['path'] = $value;
                            $img_insert['linkid'] = $res;
                            $img_insert['admin_id'] = $this->session->userdata('admin_id');
                            $img_insert['create_time'] = time();
                            //图片插入数据库失败未做处理
                            $status = $this->project_image->addData($img_insert);
                        }
                        
                    }
                    $this->show_message('success', '发布成功', site_url($this->admin_url.'/project/index'));
                }else{
                    $this->show_message('error', '发布失败', site_url($this->admin_url.'/project/index'));
                }
        }else{
            $data['_title'] = '发布项目';
            $data['project_classify'] = $this->config->config['project_classify'];
            $data['project_status'] = $this->config->config['project_status'];

            $this->render($this->admin_folder.'/project_add',$data);
        }
    }

    /**
     * 编辑项目
     */
    public function edit($id=0){
        if ( empty( $id ) ){
            $this->show_message('error', '参数错误', site_url($this->admin_url.'/project/index'));
        }
        $data = array();
        $data['active_menu'] = 'project_edit';
        
        if ( IS_POST || $this->form_validation->run('project_add') ){
            //查询项目
            $info = $this->project->getFind(array('project.id'=>$id));

            $post_data = $this->project->createData();
            //如果项目置顶则不更新状态
            if($info->status == 2){
                unset($post_data['status']);
            }
            $imgs_data = $this->input->post('imgs'); //图片单独处理

            $res = $this->project->updateData( array('id'=>$id), $post_data);
            if ( $res ){
		$this->load->model('Search_model','search');
       		if($post_data['status'] == 0){
            		$this->search->delData(array('type'=>1, 'linkid'=>$id));
       		}else{
           		if(!$this->search->getTotal(array('type'=>1, 'linkid'=>$id))){
                		$searchData = array('type'=>1, 'linkid'=>$id, 'title'=>$post_data['title'],
                        		'brief'=>mb_substr(strip_tags($post_data['content']), 0, 300),
                        		'label'=>$post_data['label'],'create_time'=>$post_data['postdate'],
                    		);
                		$this->search->addData($searchData);
           		}
       		}

                //图片处理
                if($imgs_data){
                    $this->load->model('Project_image_model','project_image');
                    //1.根据关联ID查询图片是否存在
                    $is_img = $this->project_image->getDataObj(array('linkid'=>$id));
                    if($is_img){
                        //2.根据关联ID删除图片
                        $this->project_image->deleteData(array('linkid'=>$id));
                    }
                    //3.插入编辑后的图片
                    foreach ($imgs_data as $key => $value) {
                        $img_insert['path'] = $value;
                        $img_insert['linkid'] = $id;
                        $img_insert['admin_id'] = $this->session->userdata('admin_id');
                        $img_insert['create_time'] = time();
                        //图片插入数据库失败未做处理
                        $status = $this->project_image->addData($img_insert);
                    }
                }
                $this->show_message('success','操作成功', site_url($this->admin_url.'/project/index'));
            }else{
                $this->show_message('error','操作失败', site_url($this->admin_url.'/project/index'));
            }
        }else{
            $data['info'] = $this->project->getFind(array('project.id'=>$id));
            $data['project_classify'] = $this->config->config['project_classify'];
            $data['project_status'] = $this->config->config['project_status'];

            //获取图片
            $this->load->model('Project_image_model','project_image');
            $data['imgs'] = $this->project_image->getDataObj(array('linkid'=>$id),'*',60);

            $this->load->vars('_title', '编辑项目');
            $this->load->view($this->admin_folder.'/project_add', $data);
        }
    }

    /**
     * 删除项目数据
     */
    public function del(){
        $id = intval( $this->input->post('id') );
        $data['active_menu'] = 'project_del';
        if ( empty( $id ) ){
            ajaxreturn(0,'参数错误');
        }
        $info = $this->project->get_by('id',$id);
        if(empty($info)){
            ajaxreturn(2,'新闻不存在');
            return;
        }
        $res = $this->project->deleteData(array('id'=>$id));
        if(!$res){
            ajaxreturn(3, '删除失败');
        }else{
            ajaxreturn(1, '删除成功');
        }
    }

	/*
     * 异步查询
     */
    public function search()
    {
        //判断请求类型
        if(!empty($_POST))
        {
            $keywords = $this->input->post('keywords');
            $page = $this->input->post('page');
            $status = $this->input->post('status');
			$classify = $this->input->post('classify');
			$project_classify = $this->config->config['project_classify']; //项目分类
			$project_status = $this->config->config['project_status'];  //项目状态

            $order = 'project.id desc';
            $where = array();

            if($status > 1){
                $order = 'top_time desc';
            }

            if($status != -1){
				$where['project.status'] = $status;
            }

            if($classify != -1){
                $where['project.classify'] = $classify;
            }
            
            $search = array('keywords'=>$keywords);

            $total_count = $this->project->getCountData($where, $search);
            $page_size = $this->config->item('default_limit');
            $pagination = ajax_page($total_count, $page_size, $page);
            $page = ($page-1)*$page_size;

            $topic_list = $this->project->get_project_back_list($where,$order,$page_size,$page,$search);
            //echo $this->db->last_query();
            $list = '';

            foreach($topic_list as $item)
            {
                $list .= '<tr>';
                $list .= '<td>';
                $list .= $item->id;
                $list .= '</td>';
                $list .= '<td>';
                $list .= '<a href="'.site_url("/project/detail/".$item->id).'" target="_blank" title="'.$item->title.'">'.$item->title.'</a>';
                $list .= '</td>';
                $list .= '<td>';
                $list .= $project_classify[$item->classify];
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->address;
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->project_scale;
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->hits;
                $list .= '</td>';
                $list .= '<td id="top_status_'.$item->id.'">';
                if($item->status == 0){
               	$list .= '<span class="label label-important">待处理</span>';
                }elseif($item->status == 1){
                $list .= '<span class="label label">已发布</span>';
                }elseif($item->status == 2){
                $list .='<span class="label label-warning">列表已置顶</span>';
                }
                $list .= '</td>';
                $list .= '<td>';
                $list .= $item->username;
                $list .= '</td>';
                $list .= '<td>';
                $list .= time_format($item->postdate);
                $list .= '</td>';
                $list .= '<td>';
                if($item->status == 2){
                    $list .= '<a href="/manage/project/edit/'.$item->id.'">编辑</a> | <a href="javascript:void(0)" onclick="untops('.$item->classify.','.$item->id.')">取消置顶</a> | <a href="javascript:void(0)" onclick="del('.$item->id.')">删除</a>';
                }else{
                    $list .= '<a href="/manage/project/edit/'.$item->id.'">编辑</a> | <a href="javascript:void(0)" onclick="tops('.$item->classify.','.$item->id.')">列表置顶</a> | <a href="javascript:void(0)" onclick="del('.$item->id.')">删除</a>';
                }
                $list .= '</td>';
                $list .= '</tr>';
            }
            echo json_encode(array('code' => 1, 'list' => $list, 'pagination' => $pagination));
            return;
        }
        echo json_encode(array('code' => 0));
    }
    
    /**
     * 添加置顶
     */
    public function tops(){
        $type = $this->input->post('type');
        $id = intval( $this->input->post('id') );
        $data['active_menu'] = 'project_tops';
        if ( empty( $id ) ){
            ajaxreturn(0,'参数错误');
            return;
        }
        $project_list = $this->project->getDataObj(array('classify'=>$type,'status'=>2),'id',12,0,'top_time desc');
        
        $info = $this->project->get_by('id',$id);
        if(empty($info)){
            ajaxreturn(2,'项目不存在');
            return;
        }
        $post_data['top_time'] = time();
        $post_data['status'] = 2;
        $res = $this->project->updateData(array('id'=>$id),$post_data);
        
        if($res){
            //列表置顶超过12个会置顶时间设置成0
            if(count($project_list)>=12) {
                $end_res = end($project_list);
                $this->project->updateData(array('id'=>$end_res->id),array('status'=>1,'top_time'=>0));
            }
            ajaxreturn(1, '添加列表置顶成功');
        }else{
            ajaxreturn(3, '添加列表置顶失败');
        }
    }

    /**
     * 取消置顶
     */
    public function untops(){
        $type = $this->input->post('type');
        $id = intval( $this->input->post('id') );
        $data['active_menu'] = 'project_tops';
        if ( empty( $id ) ){
            ajaxreturn(0,'参数错误');
            return;
        }

        $info = $this->project->get_by('id',$id);
        if(empty($info)){
            ajaxreturn(2,'项目不存在');
            return;
        }
        
        $res = $this->project->updateData(array('id'=>$id),array('status'=>1,'top_time'=>0));
        
        if($res){
            ajaxreturn(1, '取消列表置顶成功');
        }else{
            ajaxreturn(3, '取消列表置顶失败');
        }
    }
}
