
function ismobile() {
	var u = navigator.userAgent, app = navigator.appVersion;
	if (/AppleWebKit.*Mobile/i.test(navigator.userAgent)
			|| (/MIDP|SymbianOS|NOKIA|SAMSUNG|LG|NEC|TCL|Alcatel|BIRD|DBTEL|Dopod|PHILIPS|HAIER|LENOVO|MOT-|Nokia|SonyEricsson|SIE-|Amoi|ZTE/
					.test(navigator.userAgent))) {
		if (window.location.href.indexOf("?mobile") < 0) {
			try {
				if (/iPhone|mac|iPod|iPad/i.test(navigator.userAgent)) {
					return '0';
				} else {
					return '1';
				}
			} catch (e) {
			}
		}
	} else if (u.indexOf('iPad') > -1) {
		return '0';
	} else {
		return '1';
	}
};
$(function() {
	var gototop = $('<div class="gototop"><i class="glyphicon glyphicon-menu-up"></i></div>');
	var initGototop = function(){
		var winW = $(window).width();
		var docW = $('.tr-main .container').width() || $('.index_tab_wrap .container').width();
		console.log(winW + ' - ' + docW);
		gototop.css('right',winW / 2 - docW / 2 - 40);
	};
	
	var toggleGototop = function(){
		var winH = $(window).height();
		var scrollTop = $(window).scrollTop();
		if(scrollTop > winH / 3){
			gototop.addClass('active');
		}else{
			gototop.removeClass('active');
		}
	};
	gototop.on('click',function(){
		$(window).scrollTop(0);
	});

	$(window).resize(function(){
		initGototop();
	});

	$(window).scroll(function(){
		toggleGototop();
	});
	initGototop();
	$('body').append(gototop);

	if (ismobile() == 1) {
		// navbar
		$('.navbar-nav .dropdown').each(function() {
			$(this).mouseover(function() {
				$('.navbar-nav .dropdown').removeClass('active');
				$(this).addClass('active open');
			});
			$(this).mouseout(function() {
				$(this).removeClass('active open');
			});
		})
		//footer
		$('#gSocial span').hover(function() {
			$(this).parent('li').toggleClass('active');
		});
		// trhovertab
		$('.trhovertab').each(function() {
			var that = $(this);
			$(this).on('mouseover', function() {
				this.click();
			})
		})

		// navbar
		$(window).on('scroll', function() {
			if ($(window).scrollTop() > 114) {
				$('.navbar').addClass('navbar-mini');
			} else {
				$('.navbar').removeClass('navbar-mini');
			}
		})
	};
	
	//论文评论
	/*$("#review_form").validate({
//		errorLabelContainer: $("#signupForm div.error"),
		rules : {
			content : {
				required : true,
				minlength:15,
				maxlength:200,
			},	
			name : {
				required : true,
				minlength: 2,
				maxlength: 15,
			},
			vierycode :{
				required : true,
				minlength:5,
				maxlength:5,
			}
		},
		messages : {
			content:{
				required : '请填写评论内容',
				minlength:'最少15个字符',
				maxlength:'最多为200个字符',
			},
			name : {
				required : '请填写昵称',
				minlength : '最小2个字符',
				maxlength : '最多15个字符',
			},
			vierycode :{
				required : '请填写验证码',
				minlength:'请确认验证码在填写',
				maxlength:'请确认验证码在填写',
			}
		},
		errorPlacement: function(error, element) { //错误信息位置设置方法
//			error.appendTo( element.parent().next() ); //这里的element是录入数据的对象
			$("#signupForm").append(error);
		},
		submitHandler:function(form){
            $("#review_form").ajaxSubmit({
            	type:"post",  //提交方式  
				dataType:"json", //数据类型  
				success:function(res){ //提交成功的回调函数 
					if(res.status > 0) {
						$("#review_form").clearForm();//清除表单数据
//						message_box.show(res.info, 'success');
						alert( res.info );
					}else if (res.status <= 0) {
//						message_box.show(res.info, 'error');
						alert( res.info );
						return false;
					}
				} 
            });
        } 
	});*/

});
/**
 * 获取验证码
 * @return {[type]} [description]
 */
function getcode(objid, img_width) {
	var objid = $("#" + objid);
	$.get("/publicci/getcode/?img_width=" + img_width + "&rand="
			+ Math.random(), function(data) {
		objid.html(data);
	});
}