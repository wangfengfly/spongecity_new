//图文链接
var $link_img = $("ul.practice-title-item-img");
if($(window).innerWidth() > 768){
	$link_img.on("mouseover","li",function(){
		var $height = $(this).height()/2 - 20;
		$(this).children('.practice-title-item-link').children(".img-bg").show();
		$(this).children('.practice-title-item-link').children(".img-title").show();
		$(this).children('.practice-title-item-link').children(".img-title").css("margin-top",$height+"px");
	});
	$link_img.on("mouseout","li",function(){
		$(this).children('.practice-title-item-link').children(".img-bg").hide();
		$(this).children('.practice-title-item-link').children(".img-title").hide();
	})
}

//视频模态框
var $modal = $("div.classroom-modal");
var $dialog = $("div.classroom-dialog");
var $content = $("div.classroom-content");
var $video = $("ul.classroom");
$video.on("click","li",function(){
	var $index = $(this).index();
	if($index <=2){
		$modal.show();
		$content.eq($index).show();
		$content.eq($index).siblings().hide();
		var $offset_top = $(this).offset().top;
		$dialog.css("margin-top",$offset_top+"px")
	}else{
		return
	}
})
$modal.on("click",function(){
	$(this).hide();
})
$dialog.on("click",function(){
	$modal.hide();
})


//返回顶部
var $back_top=$("div.back-top");
$back_top.on("click",function(){
    $("html,body").animate({scrollTop:0},0);
});


//滚动一定距离固定导航栏
var $top_nav = $("div.top-nav");
var $empty = $("div.empty");

var $back_top = $('div.back-top');
var $main = $("div.main");
var $main_margin = parseInt($main.css("marginRight"))-71;
if($(window).innerWidth() > 1024){
	$(window).scroll(function(){
		var $top = parseInt($(window).scrollTop());
		if($top >= 610){
			$top_nav.css({
				"position":"fixed",
				"top":"0px",
				"z-index":1000
			});
			$empty.show();
		}else{
			$top_nav.css({
				"position":"relative",
				"top":0
			});
			$empty.hide();
		}
		if($top >= 800){
			$back_top.css({
				"display":"block",
				"right":$main_margin +"px"
			});
		}else{
			$back_top.css("display","none");
		}
	})
}

//锚点位置的调整
var $header_nav = $(".header-nav");
var $practice = $(".daoyu-practice");
$header_nav.on("click",".nav-title-text",function(){
	$(this).children("span").addClass("active");
	$(this).siblings().children("span").removeClass("active");
	var $index = $(this).index() + 1;
	var $offset_top = $practice.eq($index).offset().top -120;
	$("html,body").scrollTop($offset_top);
});

$(window).on("scroll",function(){
	var winScrollTop = $(this).scrollTop();
	$practice.each(function(){
		if(winScrollTop >= $(this).offset().top-150){
          var i =parseInt($(this).attr("data-index"));
          $(".scrollTrigger[data-index='"+i+"']").children().addClass('active').parent().parent().siblings().find(".scrollTrigger").children().removeClass('active');
      }
	});
});


//手机端折叠效果
var $fold = $("div.daoyu-m");
$fold.on("click",function(){
	$(this).next().toggle();
	if($(this).next()[0].style.display == "none"){
		$(this).children("div").children("span").html("Upward");
		$(this).children("div").children(".daoyu-icon").attr("src","images/images/spongecity_03.jpg");
	}else {
		$(this).children("div").children("span").html("Down");
		$(this).children("div").children(".daoyu-icon").attr("src","images/images/spongecity_06.jpg");
		var $layer = $(".daoyu-practice-right-m");
		var $line = $(".daoyu-practice-left-m");
		$layer.each(function(index){
			var $height = $(this).height()+ 10;
			var $line_height = $line.eq(index).children("p");
			 $line_height.css({"width":"1px","height":$height});
		})
	}
})

//元素处于可视区域外时，自动折叠
/*
var $daoyu_practice = $("div.daoyu-practice");
var $daoyu_m =$("div.daoyu-m");
if($(window).innerWidth() <= 768){
	$(window).scroll(function(){
		$daoyu_practice.each(function(index){
			var $offset_top = $(this).offset().top;
			var $outerHeight = $(this).outerHeight();
			var $scrollTop = $(window).scrollTop();
			var $client_height =$(window).height();
			if(($scrollTop > $offset_top + $outerHeight) || ($scrollTop < $offset_top - $client_height)){
				$daoyu_m.eq(index).next().hide();
			}else{
				$daoyu_m.eq(index).next().show();
				$(this).siblings().children('.daoyu-m').next().hide();
				var $layer = $(".daoyu-practice-right-m");
				var $line = $(".daoyu-practice-left-m");
				$layer.each(function(index){
					var $height = $(this).height()-10;
					var $line_height = $line.eq(index).children("p");
					 $line_height.css({"width":"1px","height":$height});
				})
			}
		})
	})
}
*/